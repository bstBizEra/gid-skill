# G09 — Integration

**Trigger:** Review, merge, or otherwise integrate a proposed candidate.
**Inputs:** Exact base/head, raw diff, review findings, approvals, required checks, ownership, merge policy, dependencies.
**Capability assumptions:** A connector may lack review, policy, or merge access; unavailable live gates cannot be inferred.
**Actions:** Inspect the candidate; resolve findings; refresh checks and approvals against current head; verify live policy and authority; integrate only if authorized; record the actual result.
**Output:** Review disposition and observed integration state, with evidence links.
**Exit and recovery:** Any stale gate, unresolved blocking finding, changed candidate, or unknown authority returns to review/verification. Record a failed integration attempt without claiming success.
**Authority limit:** Approval of a review or passing old checks does not authorize or prove a merge.
