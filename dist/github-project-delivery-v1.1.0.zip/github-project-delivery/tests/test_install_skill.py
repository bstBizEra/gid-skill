import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).parents[1] / "scripts" / "install_skill.py"
SOURCE = Path(__file__).parents[1]


class InstallSkillTests(unittest.TestCase):
    def run_installer(self, destination, *extra):
        return subprocess.run([sys.executable, str(SCRIPT), "--destination", str(destination), *extra], text=True, capture_output=True)

    def test_preview_does_not_create_destination(self):
        with tempfile.TemporaryDirectory() as temp:
            destination = Path(temp) / "skills"
            result = self.run_installer(destination)
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            self.assertFalse((destination / SOURCE.name).exists())
            self.assertIn("preview", result.stdout.lower())

    def test_apply_copies_and_identical_rerun_is_safe(self):
        with tempfile.TemporaryDirectory() as temp:
            destination = Path(temp) / "skills"
            result = self.run_installer(destination, "--apply")
            target = destination / SOURCE.name
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            self.assertEqual((target / "SKILL.md").read_bytes(), (SOURCE / "SKILL.md").read_bytes())
            repeated = self.run_installer(destination, "--apply")
            self.assertEqual(repeated.returncode, 0, repeated.stderr + repeated.stdout)
            self.assertIn("identical", repeated.stdout.lower())

    def test_conflicting_destination_is_preserved(self):
        with tempfile.TemporaryDirectory() as temp:
            destination = Path(temp) / "skills"
            target = destination / SOURCE.name
            target.mkdir(parents=True)
            (target / "SKILL.md").write_text("owner content", encoding="utf-8")
            result = self.run_installer(destination, "--apply")
            self.assertEqual(result.returncode, 1)
            self.assertEqual((target / "SKILL.md").read_text(encoding="utf-8"), "owner content")

    def test_recursive_destination_is_refused(self):
        result = self.run_installer(SOURCE / "nested")
        self.assertEqual(result.returncode, 2)

    def test_missing_source_is_refused(self):
        result = subprocess.run([sys.executable, str(SCRIPT), "--source", str(SOURCE / "missing"), "--destination", str(SOURCE.parent / "out")], text=True, capture_output=True)
        self.assertEqual(result.returncode, 2)


if __name__ == "__main__":
    unittest.main()
