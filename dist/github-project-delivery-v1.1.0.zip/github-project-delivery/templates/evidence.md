# Evidence record

- Repository and candidate base/head:
- Acceptance IDs and result:
- Check name, actual run/command, status, revision, link, time/environment:
- Reviewers and approval state/revision:
- Dependency state and source:
- Attempts (including reserved/interrupted):
- Limits, blockers, and next action:

This record is a snapshot. It does not establish live GitHub permissions, rules, or state.
