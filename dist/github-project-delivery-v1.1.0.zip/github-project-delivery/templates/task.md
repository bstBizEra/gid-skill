# Task packet

- Repository / issue:
- Outcome:
- Scope and exclusions:
- Authority and allowed actions:
- Candidate base/head:
- Acceptance criteria:
- Dependencies / blockers:
- Verification plan:
- Attempt budget / ledger:
- Completion boundary:
